"""Materialize and supervise reproducible diagnostic simulations."""

import argparse
import copy
import hashlib
import json
import shutil
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path


START_BYTES = 8_000_000_000
HARD_FLOOR_BYTES = 6_000_000_000


class DiskSpaceError(RuntimeError):
    """Raised when a diagnostic run cannot safely use the available disk."""


def deep_merge(base: dict, patch_value: dict) -> dict:
    """Recursively merge a configuration patch without mutating either input."""
    result = copy.deepcopy(base)
    for key, value in patch_value.items():
        if isinstance(value, dict) and isinstance(result.get(key), dict):
            result[key] = deep_merge(result[key], value)
        else:
            result[key] = copy.deepcopy(value)
    return result


def available_bytes(path: Path) -> int:
    """Return free bytes on the filesystem containing *path*."""
    return shutil.disk_usage(path).free


def require_start_space(path: Path, threshold_bytes: int = START_BYTES) -> int:
    """Return free bytes, or stop before a run that lacks its reserved space."""
    free = available_bytes(path)
    if free < threshold_bytes:
        raise DiskSpaceError(f"available={free} below start threshold={threshold_bytes}")
    return free


def materialize_config(
    base_path: Path,
    patch_path: Path,
    output_path: Path,
    horizon_s: float,
    seed: int,
) -> dict:
    """Create a case-specific simulator configuration and return its contents."""
    base = json.loads(base_path.read_text())
    patch = json.loads(patch_path.read_text())
    case = patch["case"]
    config = deep_merge(base, patch["overrides"])
    config["execute"]["time-total"] = horizon_s
    config["execute"]["random-seed"] = seed
    config["output_path"] = str(output_path.parent)
    config["run_suffix"] = f"_{case}_seed_{seed}_{horizon_s:g}s"

    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(config, indent=2) + "\n")
    return config


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _git_output(project_root: Path, *arguments: str) -> str:
    result = subprocess.run(
        ["git", *arguments],
        cwd=project_root,
        check=False,
        capture_output=True,
        text=True,
    )
    return result.stdout.strip() if result.returncode == 0 else "unknown"


def _termination_reason(returncode: int | None) -> str:
    if returncode == 0:
        return "completed"
    if returncode is not None and returncode < 0:
        return "simulator_signal"
    return "simulator_nonzero_exit"


def run_diagnostic(
    case: str,
    horizon_s: float,
    seed: int,
    binary_path: Path,
    output_root: Path,
    project_root: Path,
) -> dict:
    """Run one configured diagnostic case, stopping it before disk exhaustion."""
    case = case.upper()
    patch_paths = {
        "H0": project_root / "config" / "diagnostics" / "h0_historical.json",
        "C1": project_root / "config" / "diagnostics" / "c1_claim_aligned.json",
        "U0": project_root / "config" / "diagnostics" / "u0_uncertainty_ablation.json",
    }
    if case not in patch_paths:
        raise ValueError(f"unknown diagnostic case: {case}")

    output_root.mkdir(parents=True, exist_ok=True)
    free_bytes_before = require_start_space(output_root)
    case_root = output_root / case
    config_path = case_root / "config.materialized.json"
    config = materialize_config(
        project_root / "config" / "config.json",
        patch_paths[case],
        config_path,
        horizon_s,
        seed,
    )
    started_at = datetime.now(timezone.utc).isoformat()
    stdout_path = case_root / "stdout.log"
    stderr_path = case_root / "stderr.log"

    with stdout_path.open("w") as stdout_file, stderr_path.open("w") as stderr_file:
        process = subprocess.Popen(
            [str(binary_path), str(config_path)],
            cwd=project_root,
            stdout=stdout_file,
            stderr=stderr_file,
            text=True,
        )
        termination_reason = None
        while process.poll() is None:
            if available_bytes(output_root) < HARD_FLOOR_BYTES:
                process.terminate()
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait()
                termination_reason = "disk_hard_floor"
                break
            time.sleep(0.5)

    returncode = process.poll()
    if termination_reason is None:
        termination_reason = _termination_reason(returncode)
    free_bytes_after = available_bytes(output_root)
    ended_at = datetime.now(timezone.utc).isoformat()
    manifest = {
        "case": case,
        "base_commit": _git_output(project_root, "rev-parse", "HEAD"),
        "branch": _git_output(project_root, "rev-parse", "--abbrev-ref", "HEAD"),
        "seed": seed,
        "horizon_s": horizon_s,
        "solver": config.get("optimiser"),
        "config_sha256": _sha256(config_path),
        "binary_sha256": _sha256(binary_path),
        "free_bytes_before": free_bytes_before,
        "free_bytes_after": free_bytes_after,
        "started_at": started_at,
        "ended_at": ended_at,
        "returncode": returncode,
        "termination_reason": termination_reason,
        "output_dir": str(case_root),
    }
    (case_root / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    return manifest


def main(argv: list[str] | None = None) -> int:
    """Run the command-line diagnostic interface."""
    project_root = Path(__file__).resolve().parents[2]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case", required=True, choices=("H0", "C1", "U0"))
    parser.add_argument("--horizon", required=True, type=float, metavar="SECONDS")
    parser.add_argument("--seed", required=True, type=int)
    parser.add_argument("--binary", type=Path, default=project_root / "cmake-build-release" / "Swarm")
    parser.add_argument("--output-root", type=Path, default=project_root / "data" / "diagnostics")
    arguments = parser.parse_args(argv)

    try:
        manifest = run_diagnostic(
            case=arguments.case,
            horizon_s=arguments.horizon,
            seed=arguments.seed,
            binary_path=arguments.binary,
            output_root=arguments.output_root,
            project_root=project_root,
        )
    except DiskSpaceError as error:
        parser.error(str(error))
    print(json.dumps(manifest, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
