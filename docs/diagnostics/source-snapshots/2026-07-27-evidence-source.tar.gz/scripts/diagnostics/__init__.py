"""Diagnostic-runner utilities."""
