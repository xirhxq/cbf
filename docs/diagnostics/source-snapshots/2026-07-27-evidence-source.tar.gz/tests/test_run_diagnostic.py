import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from scripts.diagnostics.run_diagnostic import (
    DiskSpaceError,
    HARD_FLOOR_BYTES,
    START_BYTES,
    deep_merge,
    materialize_config,
    require_start_space,
    run_diagnostic,
)


class TerminatedProcess:
    def __init__(self):
        self.returncode = None
        self.terminated = False
        self.killed = False

    def poll(self):
        return self.returncode

    def terminate(self):
        self.terminated = True

    def wait(self, timeout=None):
        self.returncode = -15
        return self.returncode

    def kill(self):
        self.killed = True
        self.returncode = -9


class CompletedAfterOnePollProcess(TerminatedProcess):
    def __init__(self):
        super().__init__()
        self.poll_count = 0

    def poll(self):
        self.poll_count += 1
        return None if self.poll_count == 1 else 0


class DiagnosticRunnerTests(unittest.TestCase):
    def test_deep_merge_preserves_unmodified_nested_values(self):
        base = {"execute": {"time-step": 0.5, "time-total": 500}, "cbfs": {"safety": {"on": False}}}
        patch_value = {"execute": {"time-total": 20}}
        self.assertEqual(
            deep_merge(base, patch_value),
            {"execute": {"time-step": 0.5, "time-total": 20}, "cbfs": {"safety": {"on": False}}},
        )

    @patch("scripts.diagnostics.run_diagnostic.available_bytes", return_value=7_999_999_999)
    def test_start_space_below_eight_gb_aborts(self, _available):
        with self.assertRaises(DiskSpaceError):
            require_start_space(Path("/private/tmp"), 8_000_000_000)

    @patch("scripts.diagnostics.run_diagnostic.available_bytes", return_value=9_000_000_000)
    def test_default_start_space_allows_nine_gb(self, _available):
        self.assertEqual(require_start_space(Path("/private/tmp")), 9_000_000_000)

    def test_materialize_config_applies_historical_patch_and_run_metadata(self):
        project_root = Path(__file__).resolve().parents[1]
        with tempfile.TemporaryDirectory() as temporary_directory:
            materialized_path = Path(temporary_directory) / "H0" / "config.materialized.json"
            config = materialize_config(
                project_root / "config" / "config.json",
                project_root / "config" / "diagnostics" / "h0_historical.json",
                materialized_path,
                horizon_s=20,
                seed=7,
            )

            self.assertEqual(config["initial"]["position"]["method"], "specified")
            self.assertEqual(config["execute"]["time-total"], 20)
            self.assertEqual(config["execute"]["random-seed"], 7)
            self.assertFalse(config["execute"]["check-constraint-violation"])
            self.assertEqual(config["output_path"], str(materialized_path.parent))
            self.assertEqual(config["run_suffix"], "_H0_seed_7_20s")
            self.assertEqual(json.loads(materialized_path.read_text()), config)

    def test_hard_floor_terminates_process_and_writes_manifest_artifacts(self):
        project_root = Path(__file__).resolve().parents[1]
        process = TerminatedProcess()
        with tempfile.TemporaryDirectory() as temporary_directory:
            temporary_path = Path(temporary_directory)
            binary_path = temporary_path / "Swarm"
            binary_path.write_bytes(b"diagnostic binary")
            output_root = temporary_path / "output"

            with (
                patch(
                    "scripts.diagnostics.run_diagnostic.available_bytes",
                    side_effect=[START_BYTES, HARD_FLOOR_BYTES - 1, HARD_FLOOR_BYTES - 2],
                ),
                patch("scripts.diagnostics.run_diagnostic.subprocess.Popen", return_value=process),
                patch("scripts.diagnostics.run_diagnostic._git_output", return_value="test-value"),
            ):
                manifest = run_diagnostic(
                    case="H0",
                    horizon_s=20,
                    seed=7,
                    binary_path=binary_path,
                    output_root=output_root,
                    project_root=project_root,
                )

            case_root = output_root / "H0"
            manifest_path = case_root / "manifest.json"
            self.assertTrue(process.terminated)
            self.assertFalse(process.killed)
            self.assertEqual(manifest["termination_reason"], "disk_hard_floor")
            self.assertEqual(manifest["returncode"], -15)
            self.assertEqual(manifest["free_bytes_before"], START_BYTES)
            self.assertEqual(manifest["free_bytes_after"], HARD_FLOOR_BYTES - 2)
            self.assertEqual(manifest["output_dir"], str(case_root))
            self.assertTrue((case_root / "config.materialized.json").is_file())
            self.assertTrue((case_root / "stdout.log").is_file())
            self.assertTrue((case_root / "stderr.log").is_file())
            self.assertEqual(json.loads(manifest_path.read_text()), manifest)

    def test_seven_gb_during_execution_is_above_live_hard_floor(self):
        project_root = Path(__file__).resolve().parents[1]
        process = CompletedAfterOnePollProcess()
        with tempfile.TemporaryDirectory() as temporary_directory:
            temporary_path = Path(temporary_directory)
            binary_path = temporary_path / "Swarm"
            binary_path.write_bytes(b"diagnostic binary")
            output_root = temporary_path / "output"

            with (
                patch(
                    "scripts.diagnostics.run_diagnostic.available_bytes",
                    side_effect=[11_000_000_000, 7_000_000_000, 7_000_000_000],
                ),
                patch("scripts.diagnostics.run_diagnostic.subprocess.Popen", return_value=process),
                patch("scripts.diagnostics.run_diagnostic._git_output", return_value="test-value"),
                patch("scripts.diagnostics.run_diagnostic.time.sleep"),
            ):
                manifest = run_diagnostic(
                    case="H0",
                    horizon_s=20,
                    seed=7,
                    binary_path=binary_path,
                    output_root=output_root,
                    project_root=project_root,
                )

        self.assertFalse(process.terminated)
        self.assertEqual(manifest["termination_reason"], "completed")
        self.assertEqual(manifest["free_bytes_after"], 7_000_000_000)
